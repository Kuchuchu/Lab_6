import 'package:flutter/material.dart';

class MainScreen extends StatelessWidget {

final _scaffoldKey = GlobalKey<ScaffoldState>();


@override
Widget build(BuildContext context) {
return Scaffold(
key:_scaffoldKey,
appBar: AppBar(title: Text('Возвращение значения')),
body: Center(child: Column( mainAxisAlignment: MainAxisAlignment.center,children: [
RaisedButton(onPressed: (){Navigator.pushNamed(context, '/second'); 

}, child: Text('Приступить к выбору'),),

],)
),

);

}
}

class SecondScreen extends StatelessWidget {

@override
Widget build(BuildContext context) {

return Scaffold(

appBar: AppBar(title: Text('Выберите любое значение')),
body: Center(child:
Column(mainAxisAlignment: MainAxisAlignment.center,children: [
RaisedButton(onPressed: () { Navigator.pop(context);  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
content: Text("Да!"),
));}, child: Text('Да!')),
RaisedButton(onPressed: (){ Navigator.pop(context); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
content: Text("Нет."),
)); }, child: Text('Нет.')),
],)),

);

}
}


void main() {
runApp(MaterialApp(
initialRoute: '/',
routes: {
'/':(BuildContext context) => MainScreen(),
'/second':(BuildContext context) => SecondScreen()
}

));
}